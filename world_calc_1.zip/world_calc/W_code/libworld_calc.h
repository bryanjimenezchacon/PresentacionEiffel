#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

RT_IL void __stdcall F518_672(EIF_NATURAL_16);
RT_IL EIF_NATURAL_16 __stdcall F518_671(EIF_POINTER);
RT_IL EIF_NATURAL_16 __stdcall F518_667(void);
RT_IL EIF_INTEGER_32 __stdcall F580_1694(EIF_POINTER);
RT_IL EIF_NATURAL_64 __stdcall F581_1696(EIF_POINTER);
RT_IL EIF_INTEGER_32 __stdcall F627_4575(EIF_INTEGER_32, EIF_INTEGER_32);
RT_IL EIF_BOOLEAN __stdcall F631_4752(EIF_POINTER, EIF_POINTER);
RT_IL void __stdcall F672_5905(EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall F672_5907(EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall F672_5902(EIF_POINTER, EIF_INTEGER_32);
RT_IL EIF_POINTER __stdcall F672_5908(EIF_INTEGER_32, EIF_INTEGER_32);
RT_IL void __stdcall F672_5903(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL void __stdcall F672_5904(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL void __stdcall F672_5910(EIF_POINTER);
RT_IL EIF_POINTER __stdcall F672_5909(EIF_POINTER, EIF_INTEGER_32);
RT_IL EIF_INTEGER_32 __stdcall F672_5906(EIF_POINTER, EIF_POINTER, EIF_INTEGER_32);
RT_IL EIF_INTEGER_32 __stdcall F697_6544(EIF_POINTER);
RT_IL EIF_INTEGER_32 __stdcall F697_6541(EIF_INTEGER_32);
RT_IL void __stdcall F697_6546(EIF_POINTER);
RT_IL EIF_POINTER __stdcall F697_6543(EIF_INTEGER_32);
RT_IL EIF_INTEGER_32 __stdcall F697_6540(EIF_POINTER);
RT_IL EIF_INTEGER_32 __stdcall F697_6542(EIF_INTEGER_32);
RT_IL EIF_INTEGER_32 __stdcall F697_6545(void);

#ifdef __cplusplus
}
#endif

#include "eif_macros.h"
#include <string.h>
#include "eif_eiffel.h"
#include "eif_scoop.h"
#include "io.h"
#include "eif_com_exception.h"
#include <stdlib.h>